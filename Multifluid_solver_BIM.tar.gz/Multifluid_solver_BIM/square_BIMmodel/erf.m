clc;
clear all;


x= 1:0.1:5;    % vetor of x
a=1;           % series expation around a
maxn= max(size(x)); % size of vector x

erftheory= erf(x-a) ;   % matlab error function return
plot (x,erftheory,"-k")   % plot theroeatical erf vs x
xlabel ("x");
ylabel ("erf");
legend ("Theoretical");
grid on;
hold on;

%define order
order = [100 200] ;      % define order of sereies required 
symbol= ["-*","-o","-d" ];    % define symbol for plotting each order

ordermax= max(size(order));  % size or order array

for k=1:ordermax      
for i=1:maxn
    sum=0;
    for n=0:order(k)
        
        sum= sum+(-1)^n*(x(i)-a)^(2*n+1)/((2*n+1)*factorial(n));     % error funtion taylor expantion formula,  can find it series solution here:  https://en.wikipedia.org/wiki/Error_function
        %sum= sum-2^n*(-1)^n*(x(i)*x(i)+a)^(2*n+1)/((2*n+1)*factorial(n)); 
    end
    erfnumer(i)=sum*2/sqrt(pi);
end      
    error(:,k)= abs(erftheory-erfnumer); % find the abs error 
      
    plot (x,erfnumer,symbol(k));   % plot numerical error of respective order  
    hold on;
end   
   
%after running this programme uncomment the below programme to plot the symbol 

% figure
% for  k=1:ordermax
%     plot (x,error(:,k), symbol(k));
%     xlabel ("x");
%     ylabel ("Absolute error (E)");  
%     grid on;
%     hold on;
%     
% end


        