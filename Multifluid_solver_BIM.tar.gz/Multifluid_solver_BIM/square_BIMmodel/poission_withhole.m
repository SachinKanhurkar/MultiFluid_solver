clear all;
nx=601;
ny=601;
Lx=5*0.001;
Ly=5*0.001;
dx= Lx/(nx-1);
dy= Ly/(ny-1);

mu=93; ddh=5.7*10^(-6); ho=2.7678E-4; tau=0.02;
%ho=ho+ddh*(k-1)*dt;
s=12*mu*ddh/(ho^3);


x=0:dx:Lx;
y=0:dy:Ly;

n1=floor(2*0.001/dx)+1;
n2=ceil(3*0.001/dx)+1;


alpha=0.5*(dx^2)/(dx^2+dy^2);
beta= 0.5*(dy^2)/(dx^2+dy^2);
gamma=0.5*(dx^2*dy^2)/(dx^2+dy^2);

pold=zeros(nx,ny);
pnew=zeros(nx,ny);
error= 10;

Xc=[x(n2), x(n1), x(n1), x(n2), x(n2)];
Yc=[y(n2), y(n2), y(n1), y(n1), y(n2)];
plot (Xc,Yc,"*")

   area = 0; 
   for i=1:4
       area= area+ 0.5*(Xc(i)*Yc(i+1)-Xc(i+1)*Yc(i));
   end
   
  Req= sqrt(area/pi)





while error >10^(-10)
%for k=1:1000
        pold(1,:) =0;
        pold(nx,:)=0;
        pold(:,1)=0;
        pold(:,ny)=0; 
        
        
        pold (n1,n1:n2)=0;%-tau/Req;       
        pold (n2,n1:n2)=0;%-tau/Req;  
        pold (n1:n2,n1)=0;%-tau/Req;
        pold (n1:n2,n2)=0;%-tau/Req;
        
        
%         for i = n1:n2
%             for j=n1:n2
%                 pold(i,j)=-tau/Req;                
%             end
%         end 
        
        
        
        

for i=2:nx-1
    for j=2:ny-1
        
        if i>=n1 && i<=n2 && j>=n1 &&j<=n2
            pnew(i,j)=0;%-tau/Req;
        else
        
       
        %pnew(1+mod(i-1,nx-1),1+mod(j-1,ny-1))=alpha*(pold(1+mod(i-1,nx-1),1+mod(j+1-1,ny-1))+pold(1+mod(i-1,nx-1),1+mod(j-1-1,ny-1)))+beta*(pold(1+mod(i+1-1,nx-1),1+mod(j-1,ny-1))+pold(1+mod(i-1-1,nx-1),1+mod(j-1,ny-1)))-s*gamma;
        pnew(i,j)=(1/4)*(pold(i,j+1)+pold(i,j-1)+pold(i+1,j)+pold(i-1,j)-s*dx*dx) ;             
          
        error1(i,j)= abs (pnew(i,j)-pold(i,j));
        pold(i,j)= pnew(i,j);
        
        end
    end
end



       error= max (max (error1))
       fprintf("%f",pnew(n1,n1))
 
end

        for i = n1+1:n2-1
            for j=n1+1:n2-1
                pold(i,j)=-0;                
            end
        end 




% 
% 
% fid=fopen ('pressure.txt','w+');
% for i=1:nx
%     for j=1:ny
%         fprintf(fid,"%.10f     ",pnew(i,j));
%     end
%     fprintf(fid,"\n")
% end
% fclose(fid)
% 
% A= load("pressure.txt")



x=0:dx:Lx;
y=0:dy:Ly;

contourf(x,y,pold)
xlabel("x (in m)");
ylabel("y (in m)");
colorbar;
axis equal;

% A=pold(41:61,40);
% yb= y(41:61)
% dpdn=(-A)/dx
% plot (yb,dpdn)
% hold on
A=pold(161:241,160);
yb= y(161:241)
dpdn=(-A)/dx
plot (yb,dpdn)
hold on

B=load("dpdn_BIM.txt");
grid10=B(:,1)
grid20=B(:,2)
grid30=B(:,3)
grid50=B(:,4)
y1=B(:,5)

hold on;
plot (y1,grid10,"-o")
plot (y1,grid20,"-d")
plot (y1,grid30,"-s")
plot (y1,grid50,"-^")



B=load("dpdn10.txt");
grid10=B(:,1)
y1=B(:,2)
plot(y1,grid10,"-s")














