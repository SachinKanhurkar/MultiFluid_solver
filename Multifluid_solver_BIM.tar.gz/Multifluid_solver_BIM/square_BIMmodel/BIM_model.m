clear all;
nx=10;ny=10;
Lx=5*0.001;
Ly=5*0.001;
L=Lx;  %orL=Ly
dx=L/(nx); dy=L/(nx);

mu=93; ddh=5.7*10^(-6); ho=2.7678E-4; tau=0.02;
%ho=ho+ddh*(k-1)*dt;
s=12*mu*ddh/(ho^3);
hmu=ho*ho/(12*mu);

for i=1:nx+1
    for j=1:ny+1
       pd(i,j)=0
    end
end



% for i=1:nx
%     x(i)=(i-1)*Lx;
% end
% 
% for  j=1:ny
%     y(j)=(j-1)*Ly;
% end

for i=1:nx+1
    xh(i)= (i-1)*dx;
end
       
for j=1:ny+1
    yh(j)=(j-1)*dy;
end

xh=xh';
yh=yh';

for i=1:nx
    x(i)=  0.5*(xh(i+1)+xh(i));
end
for j=1:ny
    y(j)=  0.5*(yh(j+1)+yh(j));
end



%x=[1*L/6; 3*L/6; 5*L/6]
%y=[1*L/6; 3*L/6; 5*L/6]

%plot (xh,yh,"*")
x1=[xh(5);0.5*(xh(5)+xh(4)); xh(4);0.5*(xh(5)+xh(4))];
y1=[0.5*(yh(4)+yh(5)); yh(5);0.5*(yh(5)+yh(4)); yh(4)];

%plot(x1,y1,"+")
x01=[xh(5);0.5*(xh(5)+xh(4)); xh(4);0.5*(xh(5)+xh(4))];
y01=[0.5*(yh(4)+yh(5)); yh(5);0.5*(yh(5)+yh(4)); yh(4)];
 
%plot(x01,y01,"o")

x0=x(1);y0=y(1);
dt=0.001
for k=1%:15
   Xc=[x1(1); x1(1); x1(3); x1(3);x1(1) ];
   Yc=[y1(4); y1(2); y1(2);y1(4);y1(4)];
   %plot(Xc,Yc,"-")     
   
    ho=ho+ddh*dt;
    hmu=ho*ho/(12*mu);
    s=12*mu*ddh/(ho^3);
    

  %S1=0;
 % G1=0;
  
%    for i1=1:nx
%       for j1=1:ny        
%         for n1=1:100
%             for m1=1:100    
%                   G1=G1-sin(n1*pi*x(i1)/Lx)*sin(m1*pi*y(j1)/Ly)*dx*dy*s*((4/(Lx*Ly))*1/((n1*pi/Lx)^2+(m1*pi/Ly)^2));
%                %  G1=G1+(cos(n*pi*Lx/Lx)-1)*(cos(m*pi*Ly/Ly)-1)*(Lx*Ly/(n*m*pi*pi));
%             end
%         end 
%         
%       end
%   end

% 
%G1=zeros(nx,ny)



% 
% 
% G1=zeros(1000,1000);
%  for n1=1:100
%             for m1=1:100
%                 G2=0;
%                 for i1=1:nx+1
%                     for j1=1:ny+1
%                 
%                      G2=G2-sin(n1*pi*xh(i1)/Lx)*sin(m1*pi*yh(j1)/Ly)*dx*dy*s;
%                  
%                     end
%                 end
%                 
%                 G1(n1,m1)=G2;
%             end
%  end
%  
% 
% for i=1:nx+1
%     for j=1:ny +1
%         sum=0;       
%         for n=1:100
%             for m=1:100
%                  sum=sum+G1(n,m)*sin(n*pi*xh(i)/Lx)*sin(m*pi*yh(j)/Ly)*(4/(Lx*Ly))*1/((n*pi/Lx)^2+(m*pi/Ly)^2);
%               %  sum=sum+G1*sin(n*pi*x(i)/Lx)*sin(m*pi*y(j)/Ly);
%             end
%         end        
%         p(i,j)=sum;
%         
%     end
% end  


% 
% 
for i=1:nx+1
    for j=1:ny+1
        sum=0;
        for n=1:1000
            for m=1:1000
                %sum=sum-exp((2*pi/Lx)*((n*(x(i)-x0))*(m*(y(j)-y0))))*L*L/(4*pi*pi*(n*n+m*m));
                %sum=sum-cos((n*(x(i)-x0))+(m*(y(i)-y0(1))))*L*L/(4*pi*pi*(n*n+m*m));
                sum=sum-(cos(n*pi*Lx/Lx)-1)*(cos(m*pi*Ly/Ly)-1)*(Lx*Ly/(n*m*pi*pi))*((4/(Lx*Ly))*1/((n*pi/Lx)^2+(m*pi/Ly)^2))*sin(n*pi*xh(i)/Lx)*sin(m*pi*yh(j)/Ly)*s;
            end
        end        
        p(i,j)=sum;
        
    end
end


pw=p(3,4);
pe=p(5,4);
pn=p(4,5);
ps=p(4,3);

p1=[0.02/dx-pe;0.02/dx-pn;0.02/dx-pw;0.02/dx-ps];
%p1=[pe;pn;pw;ps];



%pws=p(1,1);
%pse=p(3,1);
%pwn=p(1,3);
%pne=p(3,3);

%p0=[pse; pne; pwn; pws];
p0=[0.02/dx-pe;0.02/dx-pn;0.02/dx-pw;0.02/dx-ps];
%p0=[pe;pn;pw;ps];


  
  plot(x01, y01,"*");
  hold on
 

% for i=1:4
%     phi01(i)=log(sqrt(((x1(i)-x01(1))*(x1(i)-x01(1)))+((y1(i)-y01(1))*(y1(i)-y01(1)))))/(2*pi);
%     phi02(i)=log(sqrt(((x1(i)-x01(2))*(x1(i)-x01(2)))+((y1(i)-y01(2))*(y1(i)-y01(2)))))/(2*pi);
%     phi03(i)=log(sqrt(((x1(i)-x01(3))*(x1(i)-x01(3)))+((y1(i)-y01(3))*(y1(i)-y01(3)))))/(2*pi);
%     phi04(i)=log(sqrt(((x1(i)-x01(4))*(x1(i)-x01(4)))+((y1(i)-y01(4))*(y1(i)-y01(4)))))/(2*pi); 
% end
% 
% for i=1:4
%     dphidx01(i)=(x1(i)-x01(1))/(2*pi*(((x1(i)-x01(1))*(x1(i)-x01(1)))+((y1(i)-y01(1))*(y1(i)-y01(1)))));
%     dphidx02(i)=(x1(i)-x01(2))/(2*pi*(((x1(i)-x01(2))*(x1(i)-x01(2)))+((y1(i)-y01(2))*(y1(i)-y01(2)))));
%     dphidx03(i)=(x1(i)-x01(3))/(2*pi*(((x1(i)-x01(3))*(x1(i)-x01(3)))+((y1(i)-y01(3))*(y1(i)-y01(3)))));
%     dphidx04(i)=(x1(i)-x01(4))/(2*pi*(((x1(i)-x01(4))*(x1(i)-x01(4)))+((y1(i)-y01(4))*(y1(i)-y01(4)))));
% end
%     
%  for i=1:4
%     dphidy01(i)=(y1(i)-y01(1))/(2*pi*(((x1(i)-x01(1))*(x1(i)-x01(1)))+((y1(i)-y01(1))*(y1(i)-y01(1)))));
%     dphidy02(i)=(y1(i)-y01(2))/(2*pi*(((x1(i)-x01(2))*(x1(i)-x01(2)))+((y1(i)-y01(2))*(y1(i)-y01(2)))));
%     dphidy03(i)=(y1(i)-y01(3))/(2*pi*(((x1(i)-x01(3))*(x1(i)-x01(3)))+((y1(i)-y01(3))*(y1(i)-y01(3)))));
%     dphidy04(i)=(y1(i)-y01(4))/(2*pi*(((x1(i)-x01(4))*(x1(i)-x01(4)))+((y1(i)-y01(4))*(y1(i)-y01(4)))));
% end
   

 %x01= [xh(3); 0.5*(xh(3)+xh(2)); xh(2); 0.5*(xh(3)+xh(2))];
 %y01=[0.5*(yh(3)+yh(2)); yh(3);0.5*(yh(3)+yh(2)); yh(2)];
 
    
for i=1:4
    
        sum1=0;sum2=0;sum3=0;sum4=0;
        for n=1:100
            for m=1:100
                sum1=sum1-((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(1)/Lx)*sin(m*pi*y01(1)/Ly)*sin(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
                sum2=sum2-((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(2)/Lx)*sin(m*pi*y01(2)/Ly)*sin(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
                sum3=sum3-((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(3)/Lx)*sin(m*pi*y01(3)/Ly)*sin(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
                sum4=sum4-((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(4)/Lx)*sin(m*pi*y01(4)/Ly)*sin(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
% %             
%              sum1=sum1-exp((2*pi/Lx)*((n*(x1(i)-x01(1)))*(m*(y1(i)-y01(1)))))*L*L/(4*pi*pi*(n*n+m*m));
%              sum2=sum2-exp((2*pi/Lx)*((n*(x1(i)-x01(2)))*(m*(y1(i)-y01(2)))))*L*L/(4*pi*pi*(n*n+m*m));
%              sum3=sum3-exp((2*pi/Lx)*((n*(x1(i)-x01(3)))*(m*(y1(i)-y01(3)))))*L*L/(4*pi*pi*(n*n+m*m));
%              smu4=sum4-exp((2*pi/Lx)*((n*(x1(i)-x01(4)))*(m*(y1(i)-y01(4)))))*L*L/(4*pi*pi*(n*n+m*m));
%              
             
            
            
            end
        end        
        phi01(i)=sum1;
        phi02(i)=sum2;
        phi03(i)=sum3;
        phi04(i)=sum4;
end






% 
% for i=1:4
%     phi01(i)=log(sqrt(((x1(i)-x01(1))*(x1(i)-x01(1)))+((y1(i)-y01(1))*(y1(i)-y01(1)))))/(2*pi);
%     phi02(i)=log(sqrt(((x1(i)-x01(2))*(x1(i)-x01(2)))+((y1(i)-y01(2))*(y1(i)-y01(2)))))/(2*pi);
%     phi03(i)=log(sqrt(((x1(i)-x01(3))*(x1(i)-x01(3)))+((y1(i)-y01(3))*(y1(i)-y01(3)))))/(2*pi);
%     phi04(i)=log(sqrt(((x1(i)-x01(4))*(x1(i)-x01(4)))+((y1(i)-y01(4))*(y1(i)-y01(4)))))/(2*pi); 
% end


  
for i=1:4
    s1=0;s2=0;s3=0;s4=0;
    for n=1:100
        for m=1:100
         
               s1=s1-(n*pi/Lx)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(1)/Lx)*sin(m*pi*y01(1)/Ly)*cos(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
               s2=s2-(n*pi/Lx)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(2)/Lx)*sin(m*pi*y01(2)/Ly)*cos(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
               s3=s3-(n*pi/Lx)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(3)/Lx)*sin(m*pi*y01(3)/Ly)*cos(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
               s4=s4-(n*pi/Lx)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(4)/Lx)*sin(m*pi*y01(4)/Ly)*cos(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
            
             
        end
    end
    dphidx01(i)=s1;
    dphidx02(i)=s2;
    dphidx03(i)=s3;
    dphidx04(i)=s4;
    
end
  
 
 for i=1:4
    sy1=0;sy2=0;sy3=0;sy4=0;
       for n=1:100
        for m=1:100
%             sy1=sy1+L/(2*pi*m)*sin((2*pi/L)*m*(y1(i)-y01(1)));
%             sy2=sy2+L/(2*pi*m)*sin((2*pi/L)*m*(y1(i)-y01(2)));
%             sy3=sy3+L/(2*pi*m)*sin((2*pi/L)*m*(y1(i)-y01(3)));
%             sy4=sy4+L/(2*pi*m)*sin((2*pi/L)*m*(y1(i)-y01(4)));
              sy1=sy1-(m*pi/Ly)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(1)/Lx)*sin(m*pi*y01(1)/Ly)*sin(n*pi*x1(i)/Lx)*cos(m*pi*y1(i)/Ly);
              sy2=sy2-(m*pi/Ly)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(2)/Lx)*sin(m*pi*y01(2)/Ly)*sin(n*pi*x1(i)/Lx)*cos(m*pi*y1(i)/Ly);
              sy3=sy3-(m*pi/Ly)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(3)/Lx)*sin(m*pi*y01(3)/Ly)*sin(n*pi*x1(i)/Lx)*cos(m*pi*y1(i)/Ly);
              sy4=sy4-(m*pi/Ly)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(4)/Lx)*sin(m*pi*y01(4)/Ly)*sin(n*pi*x1(i)/Lx)*cos(m*pi*y1(i)/Ly);
        end
       end
    
    dphidy01(i)=sy1;
    dphidy02(i)=sy2;
    dphidy03(i)=sy3;
    dphidy04(i)=sy4;    
 end 
  
  
   ds = sqrt((y1(2)-y1(1))^2)+sqrt((x1(2)-(x1(1)))^2);
    
   A(1,:)= phi01(:)*ds;
   A(2,:)= phi02(:)*ds;
   A(3,:)= phi03(:)*ds;
   A(4,:)= phi04(:)*ds;
   
   nx=[-1;0;1;0];
   ny=[0;-1;0;1];
   
   
    sum1=0;
    sum2=0;
    sum3=0;
    sum4=0;
    
    for i=1:4

        sum1=sum1+p1(i)*(dphidx01(i)*nx(i)+dphidy01(i)*ny(i))*ds;
        sum2=sum2+p1(i)*(dphidx02(i)*nx(i)+dphidy02(i)*ny(i))*ds;
        sum3=sum3+p1(i)*(dphidx03(i)*nx(i)+dphidy03(i)*ny(i))*ds;
        sum4=sum4+p1(i)*(dphidx04(i)*nx(i)+dphidy04(i)*ny(i))*ds;
    
    end
    
    B(1,:)=-0.5*p0(1)+sum1;
    B(2,:)=-0.5*p0(2)+sum2;
    B(3,:)=-0.5*p0(3)+sum3;
    B(4,:)=-0.5*p0(4)+sum4;
    
    
    dpdn=A\B;
%     
      for i=1:4
         x01(i)=x01(i)-dt*hmu*dpdn(i)*nx(i);
         y01(i)=y01(i)-dt*hmu*dpdn(i)*ny(i);
      end
      x1=x01;
      y1=y01;
      dx=ds;
%     plot(x01, y01,"*");
%     hold on

end
% 
% 
% % 
% %    for i=1:nx+1
% %        for j= 1:ny+1
% %            if i==1||i==nx+1||j==1||j==ny+1
% %                pd(i,j)=0;
% %            else            
% %                 pd(i,j)=p(i-1,j-1)
% %            end
% %        end
% %    end
    pmin=min(min(p));
    pmax=max(max(p));
    dp=(pmax-pmin)/10.0;
    
    pvec=[pmin:dp:pmax];
    hold off;
    contourf(xh,yh,p,pvec,'linestyle','none');
    c=colorbar;
    caxis( [pmin pmax] );
    c.Label.String = 'Pressure (in Pa)';  
    
%          set(gca,'XLim',[0 1]);
%          set(gca,'XTick',(0:0.2:1))
%          set(gca,'YTick',(0:0.2:1))
         ytickformat('%.2f')
         xtickformat('%.2f')
         set(gca,'FontSize',10);
         xlabel('x (in m)','FontSize',10), ylabel('y (in m)', 'FontSize',10),            
                
  S= p(6,:)  
  
  for i=1:11
  fid=fopen("Greenmid_pressure.txt","a+")
  fprintf(fid,"%f  %f \n",xh(i), S(i))
  end
  