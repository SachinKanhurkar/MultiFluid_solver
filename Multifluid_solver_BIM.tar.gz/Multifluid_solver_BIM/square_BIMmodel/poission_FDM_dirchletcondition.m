clear all;
nx=101;
ny=101;
Lx=5*0.001;
Ly=5*0.001;
dx= Lx/(nx-1);
dy= Ly/(ny-1);

mu=93; ddh=5.7*10^(-6); ho=2.7678E-4; tau=0.02;
%ho=ho+ddh*(k-1)*dt;
s=12*mu*ddh/(ho^3);

x=0:dx:Lx;
y=0:dy:Ly;

alpha=0.5*(dx^2)/(dx^2+dy^2);
beta= 0.5*(dy^2)/(dx^2+dy^2);
gamma=0.5*(dx^2*dy^2)/(dx^2+dy^2);

pold=zeros(nx,ny);
pnew=zeros(nx,ny);
error= 10;

%md=@(x)
md = @(a, n) (1 + mod(a-1, n-1));
n1=floor(2*0.001/dx)+1;
n2=ceil(3*0.001/dx)+1;

Xc=[x(n2), x(n1), x(n1), x(n2), x(n2)];
Yc=[y(n2), y(n2), y(n1), y(n1), y(n2)];
plot (Xc,Yc,"*")

   area = 0; 
   for i=1:4
       area= area+ 0.5*(Xc(i)*Yc(i+1)-Xc(i+1)*Yc(i));
   end
   
  Req= sqrt(area/pi)



%while error >10^(-2)
for k=1%:10000
       
       
         
%       
      
for i=2:nx
    for j=2:ny
        
%         pold(1,:) =0;
%         pold(nx,:)=0;
%         pold(:,1)=0;
%         pold(:,ny)=0;
        

        pold (n1,n1:n2)=-tau/Req;       
        pold (n2,n1:n2)=-tau/Req;  
        pold (n1:n2,n1)=-tau/Req;
        pold (n1:n2,n2)=-tau/Req;
        
         if i>=n1 && i<=n2 && j>=n1 &&j<=n2
            pnew(i,j)=-tau/Req;
        else
        
        
       %   pnew(1+mod(i-1,nx-1),1+mod(j-1,ny-1))=alpha*(pold(1+mod(i-1,nx-1),1+mod(j+1-1,ny-1))+pold(1+mod(i-1,nx-1),1+mod(j-1-1,ny-1)))+beta*(pold(1+mod(i+1-1,nx-1),1+mod(j-1,ny-1))+pold(1+mod(i-1-1,nx-1),1+mod(j-1,ny-1)))-s*gamma;
%       

 %        pnew(i,j)=(1/4)*(pold(i,j+1)+pold(i,j-1)+pold(i+1,j)+pold(i-1,j)-s*dx*dx);
%        
       
           pnew(md(i,nx),md(j,ny))=(1/4)*(pold(md(i,nx),md(j-1,ny))+pold(md(i,nx),md(j+1,ny))+pold(md(i+1,nx),md(j,ny))+pold(md(i-1,nx),md(j,ny))-s*dx*dx);
       
         end
          
          
         error1 (1+mod(i-1,nx-1),1+mod(j-1,ny-1))= abs (pnew(1+mod(i-1,nx-1),1+mod(j-1,ny-1))-pold(1+mod(i-1,nx-1),1+mod(j-1,ny-1)));
        % pold (i,j)=pnew (i,j);
        %  pold(1+mod(i-1,nx-1),1+mod(j-1,ny-1)) =pnew(1+mod(i-1,nx-1),1+mod(j-1,ny-1));   
%          pold(i,j) = pnew(i,j);
%          pold(1,:)=pnew (1,:);
%          pold(:,1)=pnew(:,1);
         
    end
end

      
          pnew(nx,:)=pnew(1,:);
          pnew(:,ny)=pnew(:,1);


          pold= pnew;




       error= max (max (error1));
 
end
x=0:dx:Lx;
y=0:dy:Ly;

contourf(x,y,pold)
xlabel("x");
ylabel("y")
colorbar


