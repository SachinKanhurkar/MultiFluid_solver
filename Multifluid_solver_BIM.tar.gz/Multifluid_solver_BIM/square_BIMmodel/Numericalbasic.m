% Array in matlab

%Array Creation


a = [1 2 3 4];

a = [1 2 3; 4 5 6; 7 8 10];


z = zeros(5,1);



%Matrix and Array Operations

b=a + 10 ;  %

C=sin(a);


%To transpose a matrix, use a single quote ('):
d= a';

p = a*inv(a);  %which computes the inner products between rows and columns, using the * operator


%you can display more decimal digits using the format command:

format long
p = a*inv(a);


%Reset the display to the shorter format using
format short

p = a.*a;


%%%%%%%%%%%%%%%%%%%%%%
p=a.^3;

%Concatenation: Concatenation is the process of joining arrays to make

%%%%%%%%%%%%%%%%%%%%

A = [a,a];

%%%%%%%%%%%%%%%%%%%
A = [a; a]

%%%%%%%%%%%%%%%%%%%%

%Array Indexing

A(3,:)
%%%%%%%%%%%%%%

B = 0:10:100

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%loops in matlab

s = 10;
H = zeros(s);

for c = 1:s
    for r = 1:s
        H(r,c) = 1/(r+c-1);
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
nrows = 4;
ncols = 6;
A = ones(nrows,ncols);

for c = 1:ncols
    for r = 1:nrows
        
        if r == c
            A(r,c) = 2;
        elseif abs(r-c) == 1
            A(r,c) = -1;
        else
            A(r,c) = 0;
        end
        
    end
end
A
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

n = 10;                        %%%%%%%%find the factorial loop
f = n;
while n > 1
    n = n-1;
    f = f*n;
end

%%%%%%%%%%%%%%%%%%%%%%



