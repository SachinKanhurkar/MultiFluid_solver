clear all;
nx=15;ny=15;
Lx=5*0.001;
Ly=5*0.001;
L=Lx;  %orL=Ly
dx=L/nx; dy=L/nx;

mu=93; ddh=5.7*10^(-6); ho=2.7678E-4; tau=0.02;
%ho=ho+ddh*(k-1)*dt;
s=12*mu*ddh/(ho^3);
hmu=ho*ho/(12*mu);

% for i=1:nx
%     x(i)=(i-1)*Lx;
% end
% 
% for  j=1:ny
%     y(j)=(j-1)*Ly;
% end

for i=1:nx+1
    xh(i)= (i-1)*dx;
end
       
for j=1:ny+1
    yh(j)=(j-1)*dy;
end

for i=1:nx
    x(i)=  0.5*(xh(i+1)+xh(i));
end
for j=1:ny
    y(j)= 0.5*(yh(j+1)+yh(j));
end


t = (1/16:1/8:1+1/16)'*2*pi;
%t(9)=t(1)
xl = 1*0.001*cos(t)+ 0.5*Lx;    %front marker
yl = 1*0.001*sin(t)+ 0.5*Ly;
plot(xl,yl)
axis square
hold on

%xl(9)=xl(1);
%yl(9)=yl(1);

for i=1:8
    slope(i)=(yl(i)-yl(i+1))/(xl(i)-xl(i+1));
end
 
for k=1:8
    x1(k)=(xl(k+1)+xl(k))*0.5; %center of edge
    y1(k)=(yl(k+1)+yl(k))*0.5;
end
   
  %  hold on 
  %  plot(x1,y1,'*') 
    
%x=[1*L/6; 3*L/6; 5*L/6]
%y=[1*L/6; 3*L/6; 5*L/6]

%plot (xh,yh,"*")
%x1=[xh(5);0.5*(xh(5)+xh(4)); xh(4);0.5*(xh(5)+xh(4))];
%y1=[0.5*(yh(4)+yh(5)); yh(5);0.5*(yh(5)+yh(4)); yh(4)];

%plot(x1,y1,"+")
x01=x1;
y01=y1;

%x01=[xh(5);0.5*(xh(5)+xh(4)); xh(4);0.5*(xh(5)+xh(4))];
%y01=[0.5*(yh(4)+yh(5)); yh(5);0.5*(yh(5)+yh(4)); yh(4)];
 
%plot(x01,y01,"o")

x0=x(1);y0=y(1);
dt=0.1


  for i=1:8
    nhatx(i)=- cosd(45*i);
    nhaty(i)=-sind(45*i);
  end  

for k=1:50
    
    
    
    
    ds(1)= sqrt((xl(1)-x1(8))^2+ (yl(1)-y1(8))^2)+sqrt((x1(1)-xl(1))^2+ (y1(1)-yl(1))^2);
  for i=2:8
    ds(i) = sqrt((xl(i)-x1(i-1))^2+ (yl(i)-y1(i-1))^2)+sqrt((x1(i)-xl(i))^2+ (y1(i)-yl(i))^2);
  end
    
    
    
    if rem(k,5)==0
       plot(Xc(:),Yc(:),'-*')
       hold on
    end
    
   
    ho=ho+ddh*dt
    hmu=ho*ho/(12*mu);
    s=12*mu*ddh/(ho^3);
    
    count= 0
  for i =1:nx+1
    for j = 1 : ny+1
        count=count+1
        P(count,:)=[xh(i), yh(j)] 
    
    end
  end

DT = delaunayTriangulation(P)
NTriangles = size(DT.ConnectivityList,1);
% Triangles' Area Calculation (Try to vectorize)
Areas = zeros(NTriangles,1);
for i = 1:NTriangles
    PointIndexes = DT.ConnectivityList(i,:);
    Areas(i) = polyarea(DT.Points(PointIndexes,1),DT.Points(PointIndexes,2));
end

IC = incenter(DT);
nic= max(size(IC))
%triplot(DT)
%hold on
%plot(IC(:,1),IC(:,2),'*r')  

in = inpolygon(IC(:,1),IC(:,2),xl,yl)

%figure

plot(xl,yl,'LineWidth',2) % polygon
axis equal
% 
hold on
% plot(IC(in,1),IC(in,2),'r+') % points inside
% plot(IC(~in,1),IC(~in,2),'bo') % points outside
% hold off


for i=1:nic      
    if IC(i,1)> x1 (8) && IC(i,1)< x1(8)-0.5*dx*nhatx(8) %&& IC(i,2)<y1(8)+0.5*dy && IC(i,2)>y1(8)-0.5*dy;
       
        n8=i
    end  
    
    if IC(i,2)> y1 (2) && IC(i,2)< y1(2)-0.5*dx*nhaty(2)% && IC(i,1)<x1(2)+0.5*dx && IC(i,1)>x1(2)-0.5*dx;
      
        n2=i
    end  
    
     if IC(i,1)< x1 (4) && IC(i,1)>x1(4)-0.5*dx*nhatx(4)% && IC(i,2)<y1(4)+0.5*dy && IC(i,2)>y1(4)-0.5*dy;
 
        n4=i
     end  
    
     if IC(i,2)< y1 (6) && IC(i,2)> y1(6)-0.5*dx*nhaty(6) %&& IC(i,1)<x1(6)+0.5*dx && IC(i,1)>x1(6)-0.5*dx;
     
        n6=i
    end  
    
     if IC(i,1)> x1 (1) && IC(i,1)< x1(1)-0.5*dx*nhatx(1)% && IC(i,2)>y1(1) && IC(i,2)<y1(1)-0.5*dy*nhaty(1);      
        n1=i
     end 
    
     if IC(i,1)< x1 (3) && IC(i,1)> x1(3)-0.5*dx*nhatx(3)% && IC(i,2)>y1(3)-0.5*dy && IC(i,2)<y1(3)+0.5*dy;      
        n3=i
    end 
    
    if IC(i,1)< x1 (5) && IC(i,1)> x1(5)-0.5*dx*nhatx(5) %&& IC(i,2)<y1(5) && IC(i,2)>y1(5)-0.5*dy*nhaty(5);      
        n5=i
    end 
    
    if IC(i,1)> x1 (7) && IC(i,1)< x1(7)-0.5*dx*nhatx(7) %&& IC(i,2)<y1(7)+dy*0.5 && IC(i,2)>y1(7)-dy*0.5;      
        n7=i
    end  
end
    
    
    
    
    
    
    
    
    
for i=1:nic   
    if in(i)==0
    
        sum=0;
        for n=1:100
            for m=1:100             
                sum=sum-((4/(Lx*Ly))*1/((n*pi/Lx)^2+(m*pi/Ly)^2))*sin(n*pi*IC(i,1)/Lx)*sin(m*pi*IC(i,2)/Ly)*sin(n*pi*x0/Lx)*sin(m*pi*y0/Ly)* Areas(i);
            end
        end        
        pr(i)=s*sum; 
    else
        pr(i)=0;
    end
    
end 

pw=pr(n4);
pe=pr(n8);
pn=pr(n2);
ps=pr(n6);
pne=pr(n1);
pnw=pr(n3);
pws=pr(n5);
pse=pr(n7);

% pw=p(2,4);
% pe=p(6,4);
% pn=p(4,6);
% ps=p(4,2);
% pne=p(6,6);
% pnw=p(2,6);
% pws=p(2,2);
% pse=p(6,2)


p1=[0.02/ds(1)-pne;0.02/ds(2)-pn;0.02/ds(3)-pnw;0.02/ds(4)-pw;0.02/ds(5)-pws;0.02/ds(6)-ps;0.02/ds(7)-pse;0.02/ds(8)-pe];


%p1=[0.02/ds(1)-pe;0.02/ds(2)-pne;0.02/ds(3)-pn;0.02/ds(4)-pnw;0.02/ds(5)-pw;0.02/ds(6)-pws;0.02/ds(7)-ps;0.02/ds(8)-pse];
%p1=[pe;pne;pn;pnw;pw;pws;ps;pse];



%pws=p(1,1);
%pse=p(3,1);
%pwn=p(1,3);
%pne=p(3,3);

%p0=[pse; pne; pwn; pws];
p0=[0.02/ds(1)-pne;0.02/ds(2)-pn;0.02/ds(3)-pnw;0.02/ds(4)-pw;0.02/ds(5)-pws;0.02/ds(6)-ps;0.02/ds(7)-pse;0.02/ds(8)-pe];
%p0=[pe;pne;pn;pnw;pw;pws;ps;pse];


  
  plot(x1, y1,"*");
  hold on
 
for i=1:8
    
        sum1=0;sum2=0;sum3=0;sum4=0;sum5=0; sum6=0; sum7=0; sum8=0;
        for n=1:100
            for m=1:100
                sum1=sum1-((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(1)/Lx)*sin(m*pi*y01(1)/Ly)*sin(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
                sum2=sum2-((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(2)/Lx)*sin(m*pi*y01(2)/Ly)*sin(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
                sum3=sum3-((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(3)/Lx)*sin(m*pi*y01(3)/Ly)*sin(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
                sum4=sum4-((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(4)/Lx)*sin(m*pi*y01(4)/Ly)*sin(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
                sum5=sum5-((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(5)/Lx)*sin(m*pi*y01(5)/Ly)*sin(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
                sum6=sum6-((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(6)/Lx)*sin(m*pi*y01(6)/Ly)*sin(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
                sum7=sum7-((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(7)/Lx)*sin(m*pi*y01(7)/Ly)*sin(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
                sum8=sum8-((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(8)/Lx)*sin(m*pi*y01(8)/Ly)*sin(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
        
            end
        end        
        phi01(i)=sum1;
        phi02(i)=sum2;
        phi03(i)=sum3;
        phi04(i)=sum4;
        phi05(i)=sum5;
        phi06(i)=sum6;
        phi07(i)=sum7;
        phi08(i)=sum8;
end

for i=1:8
    s1=0;s2=0;s3=0;s4=0;s5=0;s6=0;s7=0;s8=0;
    for n=1:100
        for m=1:100
         
               s1=s1-(n*pi/Lx)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(1)/Lx)*sin(m*pi*y01(1)/Ly)*cos(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
               s2=s2-(n*pi/Lx)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(2)/Lx)*sin(m*pi*y01(2)/Ly)*cos(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
               s3=s3-(n*pi/Lx)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(3)/Lx)*sin(m*pi*y01(3)/Ly)*cos(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
               s4=s4-(n*pi/Lx)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(4)/Lx)*sin(m*pi*y01(4)/Ly)*cos(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
               s5=s5-(n*pi/Lx)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(5)/Lx)*sin(m*pi*y01(5)/Ly)*cos(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
               s6=s6-(n*pi/Lx)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(6)/Lx)*sin(m*pi*y01(6)/Ly)*cos(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
               s7=s7-(n*pi/Lx)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(7)/Lx)*sin(m*pi*y01(7)/Ly)*cos(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
               s8=s8-(n*pi/Lx)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(8)/Lx)*sin(m*pi*y01(8)/Ly)*cos(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
            
             
        end
    end
    dphidx01(i)=s1;
    dphidx02(i)=s2;
    dphidx03(i)=s3;
    dphidx04(i)=s4;
    dphidx05(i)=s5;
    dphidx06(i)=s6;
    dphidx07(i)=s7;
    dphidx08(i)=s8;
    
end
  
 
 for i=1:8
    sy1=0;sy2=0;sy3=0;sy4=0;sy5=0;sy6=0;sy7=0;sy8=0;
       for n=1:100
        for m=1:100
              sy1=sy1-(m*pi/Ly)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(1)/Lx)*sin(m*pi*y01(1)/Ly)*sin(n*pi*x1(i)/Lx)*cos(m*pi*y1(i)/Ly);
              sy2=sy2-(m*pi/Ly)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(2)/Lx)*sin(m*pi*y01(2)/Ly)*sin(n*pi*x1(i)/Lx)*cos(m*pi*y1(i)/Ly);
              sy3=sy3-(m*pi/Ly)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(3)/Lx)*sin(m*pi*y01(3)/Ly)*sin(n*pi*x1(i)/Lx)*cos(m*pi*y1(i)/Ly);
              sy4=sy4-(m*pi/Ly)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(4)/Lx)*sin(m*pi*y01(4)/Ly)*sin(n*pi*x1(i)/Lx)*cos(m*pi*y1(i)/Ly);
              sy5=sy5-(m*pi/Ly)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(5)/Lx)*sin(m*pi*y01(5)/Ly)*sin(n*pi*x1(i)/Lx)*cos(m*pi*y1(i)/Ly);
              sy6=sy6-(m*pi/Ly)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(6)/Lx)*sin(m*pi*y01(6)/Ly)*sin(n*pi*x1(i)/Lx)*cos(m*pi*y1(i)/Ly);
              sy7=sy7-(m*pi/Ly)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(7)/Lx)*sin(m*pi*y01(7)/Ly)*sin(n*pi*x1(i)/Lx)*cos(m*pi*y1(i)/Ly);
              sy8=sy8-(m*pi/Ly)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(8)/Lx)*sin(m*pi*y01(8)/Ly)*sin(n*pi*x1(i)/Lx)*cos(m*pi*y1(i)/Ly);
       
        end
       end
    
    dphidy01(i)=sy1;
    dphidy02(i)=sy2;
    dphidy03(i)=sy3;
    dphidy04(i)=sy4;
    dphidy05(i)=sy5;
    dphidy06(i)=sy6;
    dphidy07(i)=sy7;
    dphidy08(i)=sy8;    
 end 
   
   A(1,:)= phi01(:)*ds(1);
   A(2,:)= phi02(:)*ds(2);
   A(3,:)= phi03(:)*ds(3);
   A(4,:)= phi04(:)*ds(4);
   A(5,:)= phi05(:)*ds(5);
   A(6,:)= phi06(:)*ds(6);
   A(7,:)= phi07(:)*ds(7);
   A(8,:)= phi08(:)*ds(8);
   

   
    sum1=0;
    sum2=0;
    sum3=0;
    sum4=0;
    sum5=0;
    sum6=0;
    sum7=0;
    sum8=0;    
    
    for i=1:8
        sum1=sum1+p1(i)*(dphidx01(i)*nhatx(i)+dphidy01(i)*nhaty(i))*ds(i);
        sum2=sum2+p1(i)*(dphidx02(i)*nhatx(i)+dphidy02(i)*nhaty(i))*ds(i);
        sum3=sum3+p1(i)*(dphidx03(i)*nhatx(i)+dphidy03(i)*nhaty(i))*ds(i);
        sum4=sum4+p1(i)*(dphidx04(i)*nhatx(i)+dphidy04(i)*nhaty(i))*ds(i);
        sum5=sum5+p1(i)*(dphidx05(i)*nhatx(i)+dphidy05(i)*nhaty(i))*ds(i);
        sum6=sum6+p1(i)*(dphidx06(i)*nhatx(i)+dphidy06(i)*nhaty(i))*ds(i);
        sum7=sum7+p1(i)*(dphidx07(i)*nhatx(i)+dphidy07(i)*nhaty(i))*ds(i);
        sum8=sum8+p1(i)*(dphidx08(i)*nhatx(i)+dphidy08(i)*nhaty(i))*ds(i);       
    end
    
    B(1,:)=-0.5*p0(1)+sum1;
    B(2,:)=-0.5*p0(2)+sum2;
    B(3,:)=-0.5*p0(3)+sum3;
    B(4,:)=-0.5*p0(4)+sum4;
    B(5,:)=-0.5*p0(5)+sum5;
    B(6,:)=-0.5*p0(6)+sum6;
    B(7,:)=-0.5*p0(7)+sum7;
    B(8,:)=-0.5*p0(8)+sum8;
    
    
    dpdn=A\B;
    
%     
      for i=1:8
         x01(i)=x01(i)-dt*hmu*dpdn(i)*nhatx(i);
         y01(i)=y01(i)-dt*hmu*dpdn(i)*nhaty(i);
      end
      x1=x01;
      y1=y01;  

     for i=1:2:8
        c(i)=y1(i)-slope(i)*x1(i);
     end

   xl(1)=x1(8);
   yl(1)=slope(1)*xl(1)+c(1);

   yl(1+1)=y1(1+1);
   xl(1+1)=(yl(1+1)-c(1))/slope(1) ; 
  
  for i=3:2:8
      if i==3||7
            yl(i)=y1(i-1);
            xl(i)=(yl(i)-c(i))/slope(i)   ;
    
            xl(i+1)=x1(i+1);
            yl(i+1)=slope(i)*xl(i+1)+c(i);
      end
      
      if i==5     
             xl(i)=x1(i-1);
             yl(i)=slope(i)*xl(i)+c(i);
     
             yl(i+1)=y1(i+1);
             xl(i+1)=(yl(i+1)-c(i))/slope(i)  ;
      end     
      
      xl(9)=x1(8);
      yl(9)=yl(1);   

  end
  
  end