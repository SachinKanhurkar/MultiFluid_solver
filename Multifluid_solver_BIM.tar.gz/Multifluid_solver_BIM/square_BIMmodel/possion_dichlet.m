clear all;
nx=101;
ny=101;
Lx=5*0.001;
Ly=5*0.001;
dx= Lx/(nx-1);
dy= Ly/(ny-1);

mu=93; ddh=5.7*10^(-6); ho=2.7678E-4; tau=0.02;
%ho=ho+ddh*(k-1)*dt;
s=12*mu*ddh/(ho^3);
alpha=0.5*(dx^2)/(dx^2+dy^2);
beta= 0.5*(dy^2)/(dx^2+dy^2);
gamma=0.5*(dx^2*dy^2)/(dx^2+dy^2);

pold=zeros(nx,ny);
pnew=zeros(nx,ny);
error= 10;
while error >10^(-10)
%for k=1:1000    
        pold(1,:) =0;  % update BC's
        pold(nx,:)=0;
        pold(:,1)=0;
        pold(:,ny)=0; 

for i=2:nx-1
    for j=2:ny-1    
       % pnew(1+mod(i-1,nx-1),1+mod(j-1,ny-1))=alpha*(pold(1+mod(i-1,nx-1),1+mod(j+1-1,ny-1))+pold(1+mod(i-1,nx-1),1+mod(j-1-1,ny-1)))+beta*(pold(1+mod(i+1-1,nx-1),1+mod(j-1,ny-1))+pold(1+mod(i-1-1,nx-1),1+mod(j-1,ny-1)))-s*gamma;
        pnew(i,j)=(1/4)*(pold(i,j+1)+pold(i,j-1)+pold(i+1,j)+pold(i-1,j)-s*dx*dx) ;  
    end
end

 for i=1:nx
     for j= 1:ny
      error1(i,j)= abs (pnew(i,j)-pold(i,j));
      pold(i,j)= pnew(i,j);   
     end
 end
error= max (max (error1)) ;
end


% fid=fopen ('pressure.txt','w+');
% for i=1:nx
%     for j=1:ny
%         fprintf(fid,"%.10f     ",pnew(i,j));
%     end
%     fprintf(fid,"\n")
% end
% fclose(fid)
% 
% A= load("pressure.txt")

x=0:dx:Lx;
y=0:dy:Ly;

contourf(x,y,pold)
xlabel("x (in m)");
ylabel("y (in m)");
colorbar
axis equal

G_pr=load("Greenmid_pressure.txt");
G_x= G_pr(:,1);
G_p=G_pr(:,2);

Ana_pre=load("analytical_pre.txt")

FDM_p=pold(51,:)


plot (x, FDM_p,"k-");
hold on
plot (G_x, G_p,"r--");
hold on
plot (G_x,Ana_pre);


