clear all;
nx=30;ny=30;
Lx=5*0.001;
Ly=5*0.001;
L=Lx;  %orL=Ly
dx=L/(nx-1); dy=L/(nx-1);

mu=93; ddh=5.7*10^(-6); ho=2.7678E-4; tau=0.02;
%ho=ho+ddh*(k-1)*dt;
s=12*mu*ddh/(ho^3);
hmu=ho*ho/(12*mu);

for i=1:nx
    for j=1:ny
       pd(i,j)=0;
    end
end



for i=1:nx
    xh(i)= (i-1)*dx;
end
       
for j=1:ny
    yh(j)=(j-1)*dy;
end

xh=xh';
yh=yh';

for i=1:nx-1
    x(i)=  0.5*(xh(i+1)+xh(i));
end
for j=1:ny-1
    y(j)=  0.5*(yh(j+1)+yh(j));
end

nb=20;
Ro=0.0006;
xo=Lx/2;
yo=Ly/2;
for i=1:nb
    Xc(i)=xo+Ro*cos(2*pi*(i-1)/nb);
    Yc(i)=yo+Ro*sin(2*pi*(i-1)/nb); 
    nhatx(i)=-cos(2*pi*(i-1)/nb)
    nhaty(i)=-sin(2*pi*(i-1)/nb)
end

Xc(nb+1)=Xc(1);
Yc(nb+1)=Yc(1);

for i=1:nb   
    nhatx(i)=-cos(2*pi*(i-1)/nb)
    nhaty(i)=-sin(2*pi*(i-1)/nb)
end

for i=1:nb  
    if abs(nhatx(i)) < 10^-5 
    nhatx(i)=0;
    end
    
    if abs(nhaty(i)) < 10^-5
    nhaty(i)=0;
    end
end


%plot(Xc,Yc,"-*")
%axis square
%hold on

% for k=1:4
%     x1(k)=(Xc(k+1)+Xc(k))*0.5; %center of edge
%     y1(k)=(Yc(k+1)+Yc(k))*0.5;
% end


%ds=(Xc(1)-Xc(2))/4;
% x1(5)=x1(4);
% x1(12)=x1(4);
% x1(8)=x1(2);
% x1(9)=x1(2);
% y1(6)=y1(1);
% y1(7)=y1(1);
% y1(10)=y1(3);
% y1(11)=y1(3)
% y1(5)=y1(4)+ds;
% y1(12)=y1(4)-ds;
% y1(8)=y1(2)+ds;
% y1(9)=y1(2)-ds;
% 
% x1(6)=x1(1)+ds;
% x1(7)=x1(1)-ds;
% x1(11)=x1(3)+ds;
% x1(10)=x1(3)-ds;


% ds=(Xc(1)-Xc(2))/6;
% x1(5)=x1(4);   y1(5)=y1(4)+ds;
% x1(6)=x1(4);   y1(6)=y1(4)+2*ds;
% x1(20)=x1(4);   y1(20)=y1(4)-ds;
% x1(19)=x1(4);   y1(19)=y1(4)-2*ds;
% 
% x1(11)=x1(2);   y1(11)=y1(2)+2*ds;
% x1(12)=x1(2);   y1(12)=y1(2)+ds;
% x1(13)=x1(2);   y1(13)=y1(2)-ds;
% x1(14)=x1(2);   y1(14)=y1(2)-2*ds;
% 
% 
% y1(7)=y1(1);    x1(7)=x1(1)+2*ds;
% y1(8)=y1(1);    x1(8)=x1(1)+ds;
% y1(9)=y1(1);    x1(9)=x1(1)-ds;
% y1(10)=y1(1);   x1(10)=x1(1)-2*ds;
% 
% y1(15)=y1(3);   x1(15)=x1(3)-2*ds;
% y1(16)=y1(3);   x1(16)=x1(3)-ds;
% y1(17)=y1(3);   x1(17)=x1(3)+ds;
% y1(18)=y1(3);   x1(18)=x1(3)+2*ds

% nt=24*2
% 
% ds=(Xc(1)-Xc(2))/(nt+1);
% 
% for i=1:nt
%     x1(i)=Xc(1)-i*ds   
%     y1(i)=Yc(1);
%     nhatx(i)=0;
%     nhaty(i)=-1;
% end
% 
% for i=nt+1:2*nt
%       x1(i)=Xc(2)
%       y1(i)=Yc(2)-(i-nt)*ds;
%       nhatx(i)=1;
%     nhaty(i)=0;
% end
% 
% for i=2*nt+1:3*nt
%       x1(i)=Xc(3)+(i-nt*2)*ds;
%       y1(i)=Yc(3);
%       nhatx(i)=0;
%       nhaty(i)=1; 
% end
% 
% for i=3*nt+1:nt*4
%       x1(i)=Xc(4);
%       y1(i)=Yc(4)+(i-nt*3)*ds
%       nhatx(i)=-1;
%     nhaty(i)=0;
% end




 %nb=nt*4;
%plot(x1,y1,"*");

%
% for i=1:nb
%  x1(i)=(Xc(i+1)+Xc(i))*0.5;
%  y1(i)=(Yc(i+1)+Yc(i))*0.5;
% end
 x1=Xc;
 y1=Yc;
 x01=x1;
 y01=y1;

  
%ds = sqrt((y1(1)-y1(4))^2)+sqrt((x1(1)-(x1(4)))^2); 

% 
% 
% x1=[xh(5);0.5*(xh(5)+xh(4)); xh(4);0.5*(xh(5)+xh(4))];
% y1=[0.5*(yh(4)+yh(5)); yh(5);0.5*(yh(5)+yh(4)); yh(4)];
% 
% %plot(x1,y1,"+")
% x01=[xh(5);0.5*(xh(5)+xh(4)); xh(4);0.5*(xh(5)+xh(4))];
% y01=[0.5*(yh(4)+yh(5)); yh(5);0.5*(yh(5)+yh(4)); yh(4)];
%  
% %plot(x01,y01,"o")

%x0=x(8);y0=y(8);
%dt=0.001;
 
%     nhatx=[0 1 0 -1 -1 0 0 1 1 0 0 -1];
%     nhaty=[-1 0 1 0 0 -1 -1 0 0 1 1 0]; 

%     nhatx=[0 1 0 -1 -1 -1 0 0 0 0 1 1 1 1 0 0 0 0 -1 -1];
  %   nhaty=[-1 0 1 0 0 0 -1 -1 -1 -1 0 0 0 0 1 1 1 1 0 0 ]; 






for k=1%:20
     
     if rem(k,5)==0
        plot(Xc(:),Yc(:),'-','LineWidth',2);
        axis square;
        hold on;
     end
    ho=ho%+dt*ddh;
    hmu=ho*ho/(12*mu);
    s=12*mu*ddh/(ho^3);
    
    
  count= 0;
  for i =1:nx
    for j = 1 : ny
        count=count+1;
        P(count,:)=[xh(i), yh(j)] ;
    
    end
  end

DT = delaunayTriangulation(P);

NTriangles = size(DT.ConnectivityList,1);
% Triangles' Area Calculation (Try to vectorize)
Areas = zeros(NTriangles,1);
for i = 1:NTriangles
    PointIndexes = DT.ConnectivityList(i,:);
    Areas(i) = polyarea(DT.Points(PointIndexes,1),DT.Points(PointIndexes,2));
end

IC = incenter(DT);
nic= max(size(IC));
% triplot(DT)
% hold on
% plot(IC(:,1),IC(:,2),'*r')  
% 
% 

% 
   % Xc=[x1(1); x1(1); x1(3); x1(3);x1(1)];
   % Yc=[y1(4); y1(2); y1(2);y1(4);y1(4)];
   %plot(Xc,Yc,"k-")     
   %hold on 

in = inpolygon(IC(:,1),IC(:,2),Xc,Yc);

%figure

%plot(Xc,Yc,'LineWidth',2); % polygon
% axis equal
% hold on
 
%    hold on
%    plot(IC(in,1),IC(in,2),'r+') % points inside
%    plot(IC(~in,1),IC(~in,2),'bo') % points outside
% hold off

% 
% for i=1:nic
%    
%     if in(i)==0
%    
%     if IC(i,1)> x1 (4)  && IC(i,1)< x1(4)-0.5*dx*nhatx(4) && IC(i,2)<y1(4)+0.3*dy && IC(i,2)>y1(4)-0.3*dy;       
%         n4=i   
%     
%     elseif  IC(i,1)>Xc(2)+0.2*(Xc(1)-Xc(2))&& IC(i,2)> y1 (1)  && IC(i,2)< y1(1)-0.5*dy*nhaty(1)  && IC(i,1)<Xc(1)-0.2*(Xc(1)-Xc(2)) ; %IC(i,1)< x1(1)+0.25*dx && IC(i,1)>x1(1)-0.4*dx;
%    %  if IC(i,2)> y1 (1)  && IC(i,2)< y1(1)-0.5*dy*nhaty(1) && IC(i,1)<x1(1)+0.5*dx && IC(i,1)>x1(1)-0.5*dx; 
%         n1=i     
%     
%     elseif IC(i,1)< x1 (2) && IC(i,1)>x1(2)-0.4*dx*nhatx(2) && IC(i,2)<y1(2)+0.3*dy && IC(i,2)>y1(2)-0.3*dy; 
%         n2=i       
%     
%     elseif IC(i,2)< y1 (3) && IC(i,2)> y1(3)-0.5*dy*nhaty(3)  && IC(i,1)< Xc(1)-0.2*(Xc(1)-Xc(2)) && IC(i,1)>Xc(2)+0.2*(Xc(1)-Xc(2)) ;% && IC(i,1)<x1(3)+0.25*dx && IC(i,1)>x1(3)-0.4*dx;
%      
%         n3=i
%     end  
%  end

%     
% 
%     if in(i)==0
%    
%     if IC(i,1)> x1 (4)  && IC(i,1)< x1(4)-0.5*dx*nhatx(4) && IC(i,2)<Yc(2)-0.25*(Yc(2)-Yc(3)) && IC(i,2)>Yc(3)+0.3*(Yc(2)-Yc(3));
%        
%         n4=i
%     %end  
%     
%     elseif  IC(i,1)> Xc(2)+0.2*(Xc(1)-Xc(2)) && IC(i,2)> y1 (1)  && IC(i,2)< y1(1)-0.5*dy*nhaty(1)  && IC(i,1)<Xc(1)-0.4*(Xc(1)-Xc(2)) ; %IC(i,1)< x1(1)+0.25*dx && IC(i,1)>x1(1)-0.4*dx;
%    %  if IC(i,2)> y1 (1)  && IC(i,2)< y1(1)-0.5*dy*nhaty(1) && IC(i,1)<x1(1)+0.5*dx && IC(i,1)>x1(1)-0.5*dx; 
%         n1=i
%      
%     
%     elseif IC(i,1)< x1 (2) && IC(i,1)>x1(2)-0.5*dx*nhatx(2) && IC(i,2)<Yc(2)-0.25*(Yc(2)-Yc(3)) && IC(i,2)>Yc(3)+0.1*(Yc(2)-Yc(3));
%  
%         n2=i
%        
%     
%     elseif IC(i,2)< y1 (3) && IC(i,2)> y1(3)-0.5*dy*nhaty(3)  && IC(i,1)< Xc(1)-0.25*(Xc(1)-Xc(2)) && IC(i,1)>Xc(2)+0.4*(Xc(1)-Xc(2)) ;% && IC(i,1)<x1(3)+0.25*dx && IC(i,1)>x1(3)-0.4*dx;
%      
%         n3=i
%     end  
%     end

  % fprintf("%d", i)
%     
% end
% hold on
% plot (IC(n1,1),IC(n1,2),"kX")
% 
% 
% hold on
% plot (IC(n2,1),IC(n2,2),"kd")
% 
% 
% hold on
% plot (IC(n3,1),IC(n3,2),"k+")
% 
% hold on
% plot (IC(n4,1),IC(n4,2),"k*")

 G1=zeros(2000,2000);
 for n1=1:2000
            for m1=1:2000
                G2=0;
                for i1=1:nic   
                   if in(i1)==0                
                     G2=G2-sin(n1*pi*IC(i1,1)/Lx)*sin(m1*pi*IC(i1,2)/Ly)*Areas(i1)*s;                  
                  end
                
                
                end
                G1(n1,m1)=G2;
                
           end
 end
 
holesum=0;
for i=1:nic   
    if in(i)==0        
        sum=0;       
        for n=1:2000
            for m=1:2000
                 sum=sum+G1(n,m)*sin(n*pi*IC(i,1)/Lx)*sin(m*pi*IC(i,2)/Ly)*(4/(Lx*Ly))*1/((n*pi/Lx)^2+(m*pi/Ly)^2);             
            end
        end        
        pr(i)=sum;
     else    
         pr(i)=0;
        
    end
end  


for i=1:nb
sumB=0;
        for n=1:2000
            for m=1:2000
                 sumB=sumB+G1(n,m)*sin(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly)*(4/(Lx*Ly))*1/((n*pi/Lx)^2+(m*pi/Ly)^2);             
            end
        end    
pb(i)=sumB;
end

for i=1:nb
sumC=0;sumD=0;
        for n=1:2000
            for m=1:2000
                 sumC=sumC+G1(n,m)*(n*pi/Lx)*cos(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly)*(4/(Lx*Ly))*1/((n*pi/Lx)^2+(m*pi/Ly)^2);
                 sumD=sumD+G1(n,m)*(m*pi/Ly)*sin(n*pi*x1(i)/Lx)*cos(m*pi*y1(i)/Ly)*(4/(Lx*Ly))*1/((n*pi/Lx)^2+(m*pi/Ly)^2);             
            end
        end    
dpdx_star(i)=sumC;
dpdy_star(i)=sumD;
end

for i=1:nb
   dpdn_star(i)= dpdx_star(i)*nhatx(i)+dpdy_star(i)*nhaty(i);
end
%  pw=pr(n2);
%  pe=pr(n4);
%  pn=pr(n1);
%  ps=pr(n3);

%   pw=pb(2);
%   pe=pb(4);
%   pn=pb(1);
%   ps=pb(3); 

%pavg=(pw+pe+pn+ps)/4;

  area = 0; 
   for i=1:4
       area= area+ 0.5*(Xc(i)*Yc(i+1)-Xc(i+1)*Yc(i));
   end
   
 R_eq= sqrt(area/pi);
 
 
 
 
 
 % p1=[-0.02/R_eq-pn;-0.02/R_eq-pw;-0.02/R_eq-ps;-0.02/R_eq-pe];
% % 
 % p0=[-0.02/R_eq-pn;-0.02/R_eq-pw;-0.02/R_eq-ps;-0.02/R_eq-pe];

 %p1=[-0.02/R_eq-pavg;-0.02/R_eq-pavg;-0.02/R_eq-pavg;-0.02/R_eq-pavg];
% % 
 %p0=[-0.02/R_eq-pavg;-0.02/R_eq-pavg;-0.02/R_eq-pavg;-0.02/R_eq-pavg];

 % p1=[0-pavg;0-pavg;0-pavg;0-pavg];
% % 
 % p0=[0-pavg;0-pavg;0-pavg;0-pavg];
 
 for i=1:nb
     p1(i)=-tau/Ro-pb(i);
     p0(i)=-tau/Ro-pb(i);     
 end
 
 
  
 
%   for n1=1:2000
%             for m1=1:2000
%                 G2b=0;
%                 for ib=1:4                                
%                      G2b=G2b+sin(n1*pi*Xc(ib)/Lx)*sin(m1*pi*Yc(ib)/Ly); 
%                 end
%                 G1b(n1,m1)=G2b;
%                 
%            end
%  end
%   
%   
  
  
  
  
  
 
for i=1:nb
    for j=1:nb
    
        sum1(i,j)=0;
       % sum1=0;sum2=0;sum3=0;sum4=0;sum5=0;sum6=0;sum7=0;sum8=0;sum9=0;sum10=0;sum11=0;sum12=0;
        for n=1:2000
            for m=1:2000
                sum1(i,j)=sum1(i,j)-((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(i)/Lx)*sin(m*pi*y01(i)/Ly)*sin(n*pi*x1(j)/Lx)*sin(m*pi*y1(j)/Ly);
%                 sum2=sum2-((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(2)/Lx)*sin(m*pi*y01(2)/Ly)*sin(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
%                 sum3=sum3-((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(3)/Lx)*sin(m*pi*y01(3)/Ly)*sin(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
%                 sum4=sum4-((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(4)/Lx)*sin(m*pi*y01(4)/Ly)*sin(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);

%                 sum5=sum5-((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(1)/Lx)*sin(m*pi*y01(1)/Ly)*sin(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
%                 sum6=sum5-((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(2)/Lx)*sin(m*pi*y01(2)/Ly)*sin(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
%                 sum5=sum3-((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(3)/Lx)*sin(m*pi*y01(3)/Ly)*sin(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
%                 sum4=sum4-((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(4)/Lx)*sin(m*pi*y01(4)/Ly)*sin(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
% 
%                 sum1=sum1-((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(1)/Lx)*sin(m*pi*y01(1)/Ly)*sin(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
%                 sum2=sum2-((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(2)/Lx)*sin(m*pi*y01(2)/Ly)*sin(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
%                 sum3=sum3-((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(3)/Lx)*sin(m*pi*y01(3)/Ly)*sin(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
%                 sum4=sum4-((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(4)/Lx)*sin(m*pi*y01(4)/Ly)*sin(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
% 
%                 
            end
        end        
        phi01(i,j)=sum1(i,j);
%         phi02(i)=sum2;
%         phi03(i)=sum3;
%         phi04(i)=sum4;
    end
end

  
for i=1:nb
    for j=1:nb
    s1(i,j)=0;
    %s1=0;s2=0;s3=0;s4=0;
    for n=1:2000
        for m=1:2000
         
               s1(i,j)=s1(i,j)-(n*pi/Lx)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(i)/Lx)*sin(m*pi*y01(i)/Ly)*cos(n*pi*x1(j)/Lx)*sin(m*pi*y1(j)/Ly);
%                s1=s1-(n*pi/Lx)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(1)/Lx)*sin(m*pi*y01(1)/Ly)*cos(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
%                s2=s2-(n*pi/Lx)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(2)/Lx)*sin(m*pi*y01(2)/Ly)*cos(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
%                s3=s3-(n*pi/Lx)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(3)/Lx)*sin(m*pi*y01(3)/Ly)*cos(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);
%                s4=s4-(n*pi/Lx)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(4)/Lx)*sin(m*pi*y01(4)/Ly)*cos(n*pi*x1(i)/Lx)*sin(m*pi*y1(i)/Ly);     end
        end
    end
    dphidx01(i,j)=s1(i,j);
%     dphidx01(i)=s1;
%     dphidx02(i)=s2;
%     dphidx03(i)=s3;
%     dphidx04(i)=s4;
    
    end
end
  
 
 for i=1:nb
     for j=1:nb
    sy1(i,j)=0;
    
  %  sy1=0;sy2=0;sy3=0;sy4=0;
       for n=1:2000
        for m=1:2000
              sy1(i,j)=sy1(i,j)-(m*pi/Ly)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(i)/Lx)*sin(m*pi*y01(i)/Ly)*sin(n*pi*x1(j)/Lx)*cos(m*pi*y1(j)/Ly);
%               sy1=sy1-(m*pi/Ly)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(1)/Lx)*sin(m*pi*y01(1)/Ly)*sin(n*pi*x1(i)/Lx)*cos(m*pi*y1(i)/Ly);
%               sy2=sy2-(m*pi/Ly)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(2)/Lx)*sin(m*pi*y01(2)/Ly)*sin(n*pi*x1(i)/Lx)*cos(m*pi*y1(i)/Ly);
%               sy3=sy3-(m*pi/Ly)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(3)/Lx)*sin(m*pi*y01(3)/Ly)*sin(n*pi*x1(i)/Lx)*cos(m*pi*y1(i)/Ly);
%               sy4=sy4-(m*pi/Ly)*((4/(Lx*Ly))/((n*pi/Lx)*(n*pi/Lx)+(m*pi/Ly)*(m*pi/Ly)))*sin(n*pi*x01(4)/Lx)*sin(m*pi*y01(4)/Ly)*sin(n*pi*x1(i)/Lx)*cos(m*pi*y1(i)/Ly);

        end
       end
    
    dphidy01(i,j)=sy1(i,j);
%     dphidy01(i)=sy1;
%     dphidy02(i)=sy2;
%     dphidy03(i)=sy3;
%     dphidy04(i)=sy4;    
    end 
 end
    
ds = sqrt((x1(2)-x1(1))^2+(y1(2)-y1(1))^2); 
%    A(1,:)= phi01(:)*ds;
%    A(2,:)= phi02(:)*ds;
%    A(3,:)= phi03(:)*ds;
%    A(4,:)= phi04(:)*ds;  
%    

for i=1:nb
    for j=1:nb
     A(i,j)=phi01(i,j)*ds;
    end
end
%      
     
    sum1b(1:nb)=0;
%     sum1=0;
%     sum2=0;
%     sum3=0;
%     sum4=0;
    
    for i=1:nb
       % sum1c=0;
        for j=1:nb
        sum1b(i)=sum1b(i)+p1(i)*(dphidx01(i,j)*nhatx(j)+dphidy01(i,j)*nhaty(j))*ds;
%         sum1=sum1+p1(i)*(dphidx01(i)*nhatx(i)+dphidy01(i)*nhaty(i))*ds;
%         sum2=sum2+p1(i)*(dphidx02(i)*nhatx(i)+dphidy02(i)*nhaty(i))*ds;
%         sum3=sum3+p1(i)*(dphidx03(i)*nhatx(i)+dphidy03(i)*nhaty(i))*ds;
%         sum4=sum4+p1(i)*(dphidx04(i)*nhatx(i)+dphidy04(i)*nhaty(i))*ds;    
        end
       % sum1b(i)=sum1c;
        
    end
    
%     B(1,:)=-0.5*p0(1)+sum1;
%     B(2,:)=-0.5*p0(2)+sum2;
%     B(3,:)=-0.5*p0(3)+sum3;
%     B(4,:)=-0.5*p0(4)+sum4;   
% 
for i=1:nb
    B(i)=-0.5*p0(i)+sum1b(i);
    
end

B=B';




    
    dpdn_prime=A\B;   
    
for i=1:nb
    dpdn_total(i)=dpdn_prime(i)+dpdn_star(i);
end

%       for i=1:nb
%          x01(i)=x01(i)-dt*hmu*dpdn_total(i)*nhatx(i);
%          y01(i)=y01(i)-dt*hmu*dpdn_total(i)*nhaty(i);
%       end
%       x1=x01;
%       y1=y01;
%       
%       Xc=[x1(4); x1(2); x1(2); x1(4);x1(4)];
%       Yc=[y1(1); y1(1); y1(3);y1(3);y1(1)];
%       
%       dx=ds;
%       plot(x1, y1,"*");
%       hold on
%       plot(Xc,Yc,'LineWidth',2) % polygon
%       axis equal
%       hold on

end

for i=1:nb
    ux(i)=-dpdn_total(1,i)*nhatx(1,i)*hmu;
    uy(i)=-dpdn_total(1,i)*nhaty(1,i)*hmu;
end





%    for i=1:nx+1
%        for j= 1:ny+1
%            if i==1||i==nx+1||j==1||j==ny+1
%                pd(i,j)=0;
%            else            
%                 pd(i,j)=p(i-1,j-1)
%            end
%        end
%    end
%     pmin=min(min(p));
%     pmax=max(max(p));
%     dp=(pmax-pmin)/10.0;
%     
%     pvec=[pmin:dp:pmax];
%     hold off;
%     contourf(x,y,p,pvec,'linestyle','none');
%     c=colorbar;
%     caxis( [pmin pmax] );
%     c.Label.String = 'Pressure (in Pa)';  
%     
% %          set(gca,'XLim',[0 1]);
% %          set(gca,'XTick',(0:0.2:1))
% %          set(gca,'YTick',(0:0.2:1))
%          ytickformat('%.2f')
%          xtickformat('%.2f')
%          set(gca,'FontSize',10);
%          xlabel('x (in m)','FontSize',10), ylabel('y (in m)', 'FontSize',10),    
% count=1;
% for i=1:25
%     for j=1:25
%     G_x(i,j)=IC(count,1);
%     G_y(i,j)=IC(count,2);
%     count=count+1;
%     p_G(i,j)=pr(1,count)
%     end
% end
% G_x=G_x';
% G_y=G_y';
% imagesc(IC(:,1),IC(:,2),p_G)
% 
% x = [5 8];
% y = [3 6];
% C = [0 2 4 6; 8 10 12 14; 16 18 20 22];
% imagesc(x,y,C)
% 
% contourf(G_x,G_y,p_G),'ShowText','on')
% 
% 
% 
% npr=max(size(pr));
% 
% 
% for i=1:1800
% hold on  
% plot (IC(i,1), IC(i,2), "o" )% int2str(pr(i)))
% str = {int2str(pr(i))};
% text(IC(i,1),IC(i,2),str)
% end
% 
% fid=fopen("dpdn30_nb24_nm2000.txt", "a+")
% 
% for i=nt*3+1:nt*4
% fprintf(fid, '%10.8f   %f \n',dpdn_total(i), y1(i) );
% end
% 
% 
% B=load("dpdn30.txt");
% grid10=B(:,1)
% y1=B(:,2)
% plot(y1,grid10,"-s")


%  B=load("dpdncode.txt");
%  grid10=B(1:3000,1).*nhatx(1:3000)'
% y1=B(:,2)
% plot(y1,grid10,"-s")

 fid=fopen("ux_uy30_nb20_nm2000.txt", "a+")
 for i=1:60
 fprintf(fid, "%10.12f  %10.12f \n", ux(1,i), uy(1,i))
 end
% 
% J=1:20
% g_60 =load('ux_uyFDM_c_60.txt')
% plot (J,g_60(1:3:60,2))
% hold on
% BIM =load('ux_uy30_nb60_nm2000.txt')
% plot (J, BIM(:,2))



